import React, { useCallback, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "../lib/utils.js";

const PAGES = [
	{
		id: "cover",
		theme: "light",
		kind: "cover",
		title: "Casa Verde",
		slogan: "Farm to table · Since 1992",
		image:
			"https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&w=900&q=80",
		hours: [
			{ day: "Mon – Fri", time: "11:00 – 22:00" },
			{ day: "Sat – Sun", time: "10:00 – 23:30" },
		],
	},
	{
		id: "starters",
		theme: "light",
		kind: "menu",
		heading: "Starters",
		items: [
			{ name: "Caprese Bruschetta", desc: "Tomato, basil, aged balsamic", price: "$9" },
			{ name: "Burrata Plate", desc: "Peaches, prosciutto, olive oil", price: "$14" },
			{ name: "Calamari Fritti", desc: "Lemon aioli, chili salt", price: "$13" },
			{ name: "Soup of the Day", desc: "Ask your server", price: "$8" },
		],
	},
	{
		id: "mains",
		theme: "dark",
		kind: "menu",
		heading: "Main Dishes",
		badge: "Chef's picks",
		items: [
			{ name: "Puttanesca Pasta", desc: "Olives, capers, San Marzano", price: "$26" },
			{ name: "Margherita Pizza", desc: "Fior di latte, basil", price: "$22" },
			{ name: "Grilled Branzino", desc: "Herbs, lemon butter", price: "$34" },
			{ name: "Ribeye 12oz", desc: "Chimichurri, roasted potatoes", price: "$48" },
		],
	},
	{
		id: "pizza",
		theme: "dark",
		kind: "promo",
		heading: "Pizza Menu",
		seal: "Best product · Since 1992",
		specials: [
			{ name: "Chilli Beef", price: "$15.5" },
			{ name: "Vegetarian", price: "$13.5" },
			{ name: "Spicy Chicken", price: "$14.5" },
			{ name: "Grilled Pork", price: "$15.5" },
		],
		offer: "Pizza + Mojito",
		offerPrice: "$18.5",
		image:
			"https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=700&q=80",
	},
	{
		id: "dessert",
		theme: "light",
		kind: "menu",
		heading: "Dessert",
		items: [
			{ name: "Matcha Ice Cream", desc: "House-churned, sesame", price: "$12" },
			{ name: "Chocolate Cake", desc: "Valrhona, sea salt", price: "$15" },
			{ name: "Tiramisu", desc: "Espresso, mascarpone", price: "$13" },
			{ name: "Affogato", desc: "Vanilla gelato, espresso shot", price: "$9" },
		],
	},
	{
		id: "drinks",
		theme: "dark",
		kind: "menu",
		heading: "Drinks",
		badge: "Bar",
		items: [
			{ name: "Classic Mojito", desc: "Lime, mint, soda", price: "$11" },
			{ name: "Orange Mojito", desc: "Blood orange, mint", price: "$12" },
			{ name: "Espresso Martini", desc: "Vodka, coffee liqueur", price: "$14" },
			{ name: "House Red / White", desc: "Glass · Bottle available", price: "$9" },
		],
	},
	{
		id: "back",
		theme: "light",
		kind: "back",
		title: "Thank you",
		subtitle: "See you at the table",
		web: "www.casaverde.example",
		image:
			"https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=80",
	},
];

const ease = [0.65, 0, 0.35, 1];

function PageContent({ page }) {
	const dark = page.theme === "dark";

	if (page.kind === "cover") {
		return (
			<div className="relative flex h-full overflow-hidden">
				<div className="relative w-[42%] shrink-0">
					<img
						src={page.image}
						alt=""
						className="absolute inset-0 h-full w-full object-cover"
						draggable={false}
					/>
					<div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-black/20" />
					<div className="absolute left-4 top-5 text-white sm:left-5 sm:top-6">
						<p className="font-serif text-lg font-bold tracking-wide sm:text-xl">
							{page.title}
						</p>
						<p className="mt-0.5 text-[10px] uppercase tracking-[0.16em] text-white/80">
							{page.slogan}
						</p>
					</div>
					<div className="absolute bottom-4 left-4 right-3 rounded-lg bg-white/90 p-3 text-zinc-800 backdrop-blur sm:bottom-5 sm:left-5">
						<p className="text-[10px] font-bold uppercase tracking-wider">
							Opening hours
						</p>
						{page.hours.map((row) => (
							<p key={row.day} className="mt-1 text-[11px]">
								<span className="font-medium">{row.day}</span>
								<span className="text-zinc-500"> · {row.time}</span>
							</p>
						))}
					</div>
				</div>
				<div className="flex flex-1 flex-col justify-center bg-white px-5 py-6 sm:px-7">
					<p className="font-serif text-2xl font-semibold tracking-tight text-zinc-900">
						Welcome
					</p>
					<p className="mt-2 text-xs leading-relaxed text-zinc-500">
						Seasonal plates, wood-fired pizzas, and a bar worth lingering at.
						Turn the page to explore the menu.
					</p>
					<div className="mt-6 space-y-2 border-t border-zinc-100 pt-4 text-[11px] text-zinc-400">
						<p>Reservations recommended on weekends.</p>
						<p>Ask about allergen-friendly options.</p>
					</div>
				</div>
			</div>
		);
	}

	if (page.kind === "promo") {
		return (
			<div
				className={cn(
					"relative flex h-full flex-col overflow-hidden p-5 sm:p-6",
					dark ? "bg-zinc-950 text-white" : "bg-white text-zinc-900"
				)}
			>
				<p className="text-center text-[10px] uppercase tracking-[0.2em] text-amber-400">
					{page.seal}
				</p>
				<h3 className="mt-2 text-center font-serif text-3xl font-bold tracking-tight text-amber-300 sm:text-4xl">
					{page.heading}
				</h3>
				<div className="mt-5 grid flex-1 grid-cols-2 gap-4">
					<ul className="space-y-2.5">
						{page.specials.map((item) => (
							<li key={item.name} className="flex justify-between gap-2 text-sm">
								<span className="font-medium text-amber-200">{item.name}</span>
								<span className="text-zinc-400">{item.price}</span>
							</li>
						))}
					</ul>
					<div className="flex flex-col">
						<div className="rounded-xl border border-amber-400/40 bg-amber-400/10 p-3">
							<p className="text-[10px] font-bold uppercase tracking-wider text-amber-300">
								Special offer
							</p>
							<p className="mt-1 text-sm font-semibold text-white">{page.offer}</p>
							<p className="mt-2 inline-block rounded-md bg-amber-400 px-2 py-0.5 text-xs font-bold text-zinc-950">
								Just {page.offerPrice}
							</p>
						</div>
						<div className="relative mt-3 min-h-0 flex-1 overflow-hidden rounded-xl">
							<img
								src={page.image}
								alt=""
								className="absolute inset-0 h-full w-full object-cover"
								draggable={false}
							/>
						</div>
					</div>
				</div>
				<p className="mt-4 text-center text-[10px] text-zinc-500">
					Up to 50% off with flyer · Ask your server
				</p>
			</div>
		);
	}

	if (page.kind === "back") {
		return (
			<div className="relative flex h-full overflow-hidden">
				<img
					src={page.image}
					alt=""
					className="absolute inset-0 h-full w-full object-cover"
					draggable={false}
				/>
				<div className="absolute inset-0 bg-black/45" />
				<div className="relative z-10 flex h-full w-full flex-col items-center justify-center px-6 text-center text-white">
					<p className="font-serif text-3xl font-bold sm:text-4xl">{page.title}</p>
					<p className="mt-2 text-sm text-white/80">{page.subtitle}</p>
					<p className="mt-6 text-xs tracking-wide text-white/60">{page.web}</p>
				</div>
			</div>
		);
	}

	/* menu */
	return (
		<div
			className={cn(
				"flex h-full flex-col px-6 py-6 sm:px-8 sm:py-7",
				dark ? "bg-zinc-950 text-zinc-100" : "bg-[#faf8f5] text-zinc-900"
			)}
		>
			<div className="mb-5 flex items-end justify-between gap-3 border-b pb-3"
				style={{ borderColor: dark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)" }}
			>
				<h3 className="font-serif text-2xl font-semibold tracking-tight sm:text-3xl">
					{page.heading}
				</h3>
				{page.badge && (
					<span
						className={cn(
							"rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider",
							dark ? "bg-amber-400/15 text-amber-300" : "bg-zinc-900/5 text-zinc-500"
						)}
					>
						{page.badge}
					</span>
				)}
			</div>
			<ul className="flex flex-1 flex-col gap-4">
				{page.items.map((item) => (
					<li key={item.name} className="flex items-start justify-between gap-4">
						<div>
							<p className="text-sm font-semibold tracking-wide">{item.name}</p>
							<p
								className={cn(
									"mt-0.5 text-xs",
									dark ? "text-zinc-500" : "text-zinc-500"
								)}
							>
								{item.desc}
							</p>
						</div>
						<span
							className={cn(
								"shrink-0 text-sm font-medium",
								dark ? "text-amber-300" : "text-zinc-800"
							)}
						>
							{item.price}
						</span>
					</li>
				))}
			</ul>
		</div>
	);
}

/**
 * HeroFlipbook — 3D page-turn hinged at the book center (spine).
 * Right click / next → page swings right→left; left / prev → left→right.
 */
export default function HeroFlipbook({
	pages = PAGES,
	isLight = true,
	className,
}) {
	const list = pages.length ? pages : PAGES;
	const [index, setIndex] = useState(0);
	const [dir, setDir] = useState(1); /* 1 = forward (R→L), -1 = back (L→R) */
	const [flipping, setFlipping] = useState(false);

	const canPrev = index > 0 && !flipping;
	const canNext = index < list.length - 1 && !flipping;

	const go = useCallback(
		(nextDir) => {
			if (flipping) return;
			setIndex((i) => {
				const next = i + nextDir;
				if (next < 0 || next >= list.length) return i;
				setDir(nextDir);
				setFlipping(true);
				return next;
			});
		},
		[list.length, flipping]
	);

	const page = list[index];
	/** Destination page sits under the turning sheet */
	const underPage = page;

	/**
	 * Center-spine flip:
	 *  Forward (dir=1): free edge swings right → left (−rotateY)
	 *  Backward (dir=-1): free edge swings left → right (+rotateY)
	 */
	const sheetVariants = {
		enter: (d) => ({
			rotateY: d > 0 ? 180 : -180,
			zIndex: 4,
		}),
		center: {
			rotateY: 0,
			zIndex: 4,
		},
		exit: (d) => ({
			rotateY: d > 0 ? -180 : 180,
			zIndex: 5,
		}),
	};

	return (
		<section
			className={cn(
				"relative mx-auto w-full max-w-5xl px-4 py-14 sm:px-6 sm:py-16",
				className
			)}
			aria-label="Menu flipbook"
		>
			<div className="mb-6 text-center">
				<p
					className={cn(
						"text-[11px] font-semibold uppercase tracking-[0.2em]",
						isLight ? "text-zinc-500" : "text-zinc-500"
					)}
				>
					Flipbook
				</p>
				<h2
					className={cn(
						"mt-1 text-2xl font-bold tracking-tight sm:text-3xl",
						isLight ? "text-zinc-950" : "text-white"
					)}
				>
					Restaurant menu
				</h2>
			</div>

			<div className="relative flex items-center justify-center gap-2 sm:gap-4">
				<button
					type="button"
					onClick={() => canPrev && go(-1)}
					disabled={!canPrev}
					className={cn(
						"z-20 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border shadow-md transition disabled:opacity-30",
						isLight
							? "border-zinc-200 bg-white text-zinc-800 hover:bg-zinc-50"
							: "border-zinc-700 bg-zinc-900 text-zinc-100 hover:bg-zinc-800"
					)}
					aria-label="Previous page"
				>
					<ChevronLeft className="h-5 w-5" />
				</button>

				{/* Book stage — perspective; hinge at horizontal center */}
				<div
					className="relative w-full max-w-3xl overflow-visible py-4"
					style={{ perspective: "2200px", perspectiveOrigin: "50% 50%" }}
				>
					<div
						className={cn(
							"relative aspect-[4/3] w-full overflow-visible rounded-sm shadow-2xl sm:aspect-[3/2]",
							isLight ? "bg-zinc-400/30 shadow-zinc-400/40" : "bg-zinc-800 shadow-black/50"
						)}
						style={{ transformStyle: "preserve-3d" }}
					>
						{/* Under page (destination) — sits still under the turning sheet */}
						<div
							className={cn(
								"absolute inset-0 overflow-hidden rounded-sm",
								underPage.theme === "dark" ? "bg-zinc-950" : "bg-white"
							)}
							style={{ zIndex: 1 }}
						>
							<PageContent page={underPage} />
						</div>

						{/* Center spine */}
						<div
							className="pointer-events-none absolute inset-y-0 left-1/2 z-30 w-[3px] -translate-x-1/2"
							style={{
								background:
									"linear-gradient(90deg, rgba(0,0,0,0.18), rgba(0,0,0,0.05), rgba(0,0,0,0.18))",
								boxShadow: "0 0 12px rgba(0,0,0,0.15)",
							}}
						/>

						{/* Turning sheet — hinged at horizontal center */}
						<AnimatePresence
							initial={false}
							custom={dir}
							mode="sync"
							onExitComplete={() => setFlipping(false)}
						>
							<motion.div
								key={page.id}
								custom={dir}
								className="absolute inset-0 overflow-hidden rounded-sm"
								style={{
									transformStyle: "preserve-3d",
									transformOrigin: "50% 50%",
									backfaceVisibility: "hidden",
									WebkitBackfaceVisibility: "hidden",
									boxShadow: "0 12px 40px rgba(0,0,0,0.25)",
								}}
								variants={sheetVariants}
								initial="enter"
								animate="center"
								exit="exit"
								transition={{ duration: 0.85, ease }}
							>
								<div
									className={cn(
										"absolute inset-0 h-full w-full",
										page.theme === "dark" ? "bg-zinc-950" : "bg-white"
									)}
									style={{ backfaceVisibility: "hidden" }}
								>
									<PageContent page={page} />
								</div>

								{/* Soft gradient on the turning edge for depth */}
								<div
									className="pointer-events-none absolute inset-y-0 left-0 w-1/2 opacity-30"
									style={{
										background:
											dir > 0
												? "linear-gradient(90deg, rgba(0,0,0,0.2), transparent)"
												: "linear-gradient(270deg, rgba(0,0,0,0.2), transparent)",
									}}
								/>

								<button
									type="button"
									className="absolute inset-y-0 left-0 z-40 w-1/2 cursor-w-resize bg-transparent"
									onClick={() => canPrev && go(-1)}
									aria-label="Flip previous (left to right)"
								/>
								<button
									type="button"
									className="absolute inset-y-0 right-0 z-40 w-1/2 cursor-e-resize bg-transparent"
									onClick={() => canNext && go(1)}
									aria-label="Flip next (right to left)"
								/>
							</motion.div>
						</AnimatePresence>
					</div>
				</div>

				<button
					type="button"
					onClick={() => canNext && go(1)}
					disabled={!canNext}
					className={cn(
						"z-20 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border shadow-md transition disabled:opacity-30",
						isLight
							? "border-zinc-200 bg-white text-zinc-800 hover:bg-zinc-50"
							: "border-zinc-700 bg-zinc-900 text-zinc-100 hover:bg-zinc-800"
					)}
					aria-label="Next page"
				>
					<ChevronRight className="h-5 w-5" />
				</button>
			</div>

			<div className="mt-5 flex justify-center">
				<span
					className={cn(
						"rounded-full px-3 py-1 text-xs font-medium tabular-nums",
						isLight
							? "bg-zinc-900 text-white"
							: "bg-zinc-100 text-zinc-900"
					)}
				>
					{index + 1} / {list.length}
				</span>
			</div>
		</section>
	);
}
