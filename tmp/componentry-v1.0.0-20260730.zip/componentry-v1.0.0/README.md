# Componentry v1.0.0

Sellable UI / motion hero components for Next.js + React + Tailwind + Framer Motion.

## What's included

```
components/          Hero*.jsx demos
components/cursor-trails/
components/ui/       Minimal Button + Card used by a few heroes
lib/utils.js         cn() helper (clsx + tailwind-merge)
catalog.json         Manifest of packed files
```

### Components (23)

- `HeroAppleWatch.jsx`
- `HeroCardWallet.jsx`
- `HeroCursorTrails.jsx`
- `HeroDragBoard.jsx`
- `HeroExpandGallery.jsx`
- `HeroFanStack.jsx`
- `HeroFlipbook.jsx`
- `HeroHorizontalScroll.jsx`
- `HeroIPhone.jsx`
- `HeroKineticType.jsx`
- `HeroNarratorVoice.jsx`
- `HeroOrbitRing.jsx`
- `HeroPhoneScroll.jsx`
- `HeroScreenshotCarousel.jsx`
- `HeroScrollReveal.jsx`
- `HeroStoryFilm.jsx`
- `HeroSwipeCards.jsx`
- `HeroTabStack.jsx`
- `HeroTextReel.jsx`
- `HeroThrowCollect.jsx`
- `HeroTocRail.jsx`
- `HeroVerticalDock.jsx`
- `HeroWorkList.jsx`

## Install into your app

1. Copy `components/` and `lib/` into your project (or merge into existing folders).
2. Ensure these dependencies are installed:

```bash
npm install framer-motion lucide-react clsx tailwind-merge class-variance-authority @radix-ui/react-slot
```

3. Import a hero:

```jsx
import HeroIPhone from "./components/HeroIPhone";

export default function Page() {
  return <HeroIPhone />;
}
```

4. Tailwind: use a standard Tailwind setup with content paths covering these files.

## Notes

- Paths inside the ZIP use relative imports (no `@/` alias required).
- Some demos load Unsplash images / DiceBear avatars over the network.
- Preview screenshot demos expect optional `screenshots` props — see each file.

Built for Gumroad distribution · 2026-07-30
